import pandas as pd
import numpy as np
import os

# src/my_krml_<student_id>/data_utils.py

def dataset_info(df, head_rows=5):
    print("===== Dataset Shape =====")
    print(df.shape)
    print("\n===== Dataset Info =====")
    print(df.info())
    print(f"\n===== First {head_rows} Rows =====")
    print(df.head(head_rows))


import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

import pandas as pd
from sklearn.preprocessing import StandardScaler

def preprocess_data(df):
    df = df.copy()
    for col in df.columns:
        if df[col].dtype in ["int64", "float64"]:
            df[col] = df[col].fillna(df[col].median())
        else:
            df[col] = df[col].fillna(df[col].mode()[0])
    return df

def transform_features(df, scale_numeric=True, one_hot=True):
    df = df.copy()
    num_cols = df.select_dtypes(include=["int64", "float64"]).columns
    cat_cols = df.select_dtypes(include=["object", "category"]).columns

    # Scale numeric columns
    if scale_numeric and len(num_cols) > 0:
        scaler = StandardScaler()
        df[num_cols] = scaler.fit_transform(df[num_cols])

    # One-hot encode categorical columns
    if one_hot and len(cat_cols) > 0:
        df = pd.get_dummies(df, columns=cat_cols, drop_first=True)

    return df


from sklearn.model_selection import train_test_split
def split_data(X, y, test_size=0.2, random_state=42, stratify=True):
    if stratify:
        return train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )
    else:
        return train_test_split(
            X, y, test_size=test_size, random_state=random_state
        )

