import pandas as pd
import numpy as np
import os

# src/my_krml_<student_id>/data_utils.py

def dataset_info(df, head_rows=5):
    print("===== Dataset Shape =====")
    print(df.shape)
    print("\n===== Dataset Info =====")
    print(df.info())
    print(f"\n===== First {head_rows} Rows =====")
    print(df.head(head_rows))


def pop_target(df, target_col):
    df_copy = df.copy()
    target = df_copy.pop(target_col)
    return df_copy, target



def save_sets(X_train=None, y_train=None, X_val=None, y_val=None, X_test=None, y_test=None, path='../data/processed/'):
    if X_train is not None: np.save(f'{path}X_train', X_train)
    if y_train is not None: np.save(f'{path}y_train', y_train)
    if X_val is not None: np.save(f'{path}X_val', X_val)
    if y_val is not None: np.save(f'{path}y_val', y_val)
    if X_test is not None: np.save(f'{path}X_test', X_test)
    if y_test is not None: np.save(f'{path}y_test', y_test)

def load_sets(path='../data/processed/'):
    X_train = np.load(f'{path}X_train.npy', allow_pickle=True) if os.path.isfile(f'{path}X_train.npy') else None
    y_train = np.load(f'{path}y_train.npy', allow_pickle=True) if os.path.isfile(f'{path}y_train.npy') else None
    X_val   = np.load(f'{path}X_val.npy', allow_pickle=True) if os.path.isfile(f'{path}X_val.npy') else None
    y_val   = np.load(f'{path}y_val.npy', allow_pickle=True) if os.path.isfile(f'{path}y_val.npy') else None
    X_test  = np.load(f'{path}X_test.npy', allow_pickle=True) if os.path.isfile(f'{path}X_test.npy') else None
    y_test  = np.load(f'{path}y_test.npy', allow_pickle=True) if os.path.isfile(f'{path}y_test.npy') else None
    return X_train, y_train, X_val, y_val, X_test, y_test

def split_sets_by_time(df, target_col, test_ratio=0.2):
     df_copy = df.copy()
     target = df_copy.pop(target_col)
     cutoff = int(len(df_copy) / 5)
     X_train, y_train = subset_x_y(target=target, features=df_copy, start_index=0, end_index=-cutoff*2)
     X_val, y_val     = subset_x_y(target=target, features=df_copy, start_index=-cutoff*2, end_index=-cutoff)
     X_test, y_test   = subset_x_y(target=target, features=df_copy, start_index=-cutoff, end_index=len(df_copy))
     return X_train, y_train, X_val, y_val, X_test, y_test

def split_sets_random(features, target, test_ratio=0.2):
    from sklearn.model_selection import train_test_split
    val_ratio = test_ratio / (1 - test_ratio)
    X_data, X_test, y_data, y_test = train_test_split(features, target, test_size=test_ratio, random_state=8)
    X_train, X_val, y_train, y_val = train_test_split(X_data, y_data, test_size=val_ratio, random_state=8)
    return X_train, y_train, X_val, y_val, X_test, y_test


