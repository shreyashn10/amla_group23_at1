import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, roc_curve, auc, precision_recall_curve
import numpy as np

def plot_confusion_matrix(y_true, y_pred, labels=None, title='Confusion Matrix'):
    """Plot confusion matrix as a heatmap"""
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels)
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.title(title)
    plt.show()

def plot_roc_auc(y_true, y_scores, pos_label=1, title='ROC Curve'):
    """Plot ROC curve for binary classification"""
    fpr, tpr, thresholds = roc_curve(y_true, y_scores, pos_label=pos_label)
    roc_auc = auc(fpr, tpr)

    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'AUC = {roc_auc:.2f}')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(title)
    plt.legend(loc='lower right')
    plt.show()

def plot_precision_recall_curve(y_true, y_scores, pos_label=1, title='Precision-Recall Curve'):
    """Plot precision-recall curve for binary classification"""
    precision, recall, thresholds = precision_recall_curve(y_true, y_scores, pos_label=pos_label)
    
    plt.figure(figsize=(6, 5))
    plt.plot(recall, precision, color='purple', lw=2)
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title(title)
    plt.show()

def plot_class_distribution(y, title='Class Distribution'):
    """Visualize class distribution in the dataset"""
    plt.figure(figsize=(6, 4))
    sns.countplot(x=y)
    plt.title(title)
    plt.show()

def plot_feature_importance(importances, feature_names, top_n=10, title='Top Feature Importances'):
    """Plot feature importance from a trained model"""
    indices = np.argsort(importances)[::-1][:top_n]
    plt.figure(figsize=(8, 5))
    sns.barplot(x=importances[indices], y=np.array(feature_names)[indices], palette='viridis')
    plt.title(title)
    plt.show()
