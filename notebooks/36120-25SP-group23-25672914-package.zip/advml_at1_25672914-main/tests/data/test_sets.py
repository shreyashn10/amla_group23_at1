import pytest
import pandas as pd
from advml_at1_25672914.data.sets import pop_target

@pytest.fixture
def features_fixture():
    return pd.DataFrame([[1, 25], [2, 33], [3, 42]], columns=["id", "age"])

@pytest.fixture
def target_fixture():
    return pd.Series([100, 200, 300], name="salary")

def test_pop_target(features_fixture, target_fixture):
    df = features_fixture.copy()
    df["salary"] = target_fixture
    features, target = pop_target(df, "salary")
    pd.testing.assert_frame_equal(features, features_fixture)
    pd.testing.assert_series_equal(target, target_fixture)
